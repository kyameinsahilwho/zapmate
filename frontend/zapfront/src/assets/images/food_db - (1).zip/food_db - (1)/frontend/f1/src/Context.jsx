// import React, { createContext, useState } from "react";
import  { createContext} from "react";
export const MyContext = createContext();