import React, {  useState } from "react";
import Helmet from "../components/Helmet/Helmet";
import CommonSection from "../components/UI/common-section/CommonSection";
import { Container, Row, Col } from "reactstrap";
import { Link } from "react-router-dom";
// import Home from './Home';
import axios from "axios";

const Login = () => {
  // const loginNameRef = useRef();
  // const loginPasswordRef = useRef();
  const [username,setUsername]=useState("")
  const [password,setPassword]=useState("")

  const submitHandler = async(e) => {
    e.preventDefault();
    try
    {
        await axios.post("http://localhost:5000/api/login",
        {username,password});
        alert("Login Sucessfull")
        setUsername("")
        setPassword("")
    }
    catch(err)
    {
        // console.log(err);
        alert("Login Failed")
    }
  };

  return (
    <Helmet title="Login">
      <CommonSection title="Login" />
      <section>
        <Container>
          <Row>
            <Col lg="6" md="6" sm="12" className="m-auto text-center">
              <form className="form mb-5" onSubmit={submitHandler} method="post">
                <div className="form__group">
                  <input
                    type="text"
                    placeholder="Username"
                    required
                    value={username} onChange={(e)=>setUsername(e.target.value)}
                  />
                </div>
                <div className="form__group">
                  <input
                    type="password"
                    placeholder="Password"
                    required
                    value={password} onChange={(e)=>setPassword(e.target.value)}
                  />
                </div>
                <Link to="/Home">
                <button type="submit" className="addTOCart__btn" >
                  Login
                </button>
                </Link>
                
              </form>
              <Link to="/register">
                Don't have an account? Create an account
              </Link>
            </Col>
          </Row>
        </Container>
      </section>
    </Helmet>
  );
};

export default Login;
