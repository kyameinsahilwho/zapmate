import React,{useContext} from "react";

import Helmet from "../components/Helmet/Helmet";
import CommonSection from "../components/UI/common-section/CommonSection";

import "../styles/Order.css";

import { MyContext } from "../Context";
const Order = (props) => {

  const {state} = useContext(MyContext)
  
  return (
    <Helmet title="Order">
      <CommonSection title="Order" />
      <div className="box-container">
        <div style={{ margin: 5, padding: 5 }}>
          <div className="row">
            <div className="col md-4">
              <h4>Customer Name</h4>
              <h5>{state.name}</h5>
            </div>
            <div className="col md-4">
              <h4>Number</h4>
              <h5>{state.number}</h5>
            </div>
            <div className="col md-4">
              <h4>City</h4>
              <h5>{state.city}</h5>
            </div>
          </div>
        </div>
        <h3 style={{textAlign:"center",color:"green",fontStyle:"italic"}}>Your order has been Placed Sucessfully!!!🍕🍔🥖</h3>
      </div>
    </Helmet>
  );
};

export default Order;
