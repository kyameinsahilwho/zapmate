const mg=require("mongoose")
const exp=require("express")
const app=exp()
const cors=require("cors")
const bodyparser=require("body-parser")
app.use(cors())
app.use(bodyparser.json())
const bcrypt=require("bcrypt")
mg.connect("mongodb://127.0.0.1:27017/Food");
const myschema=new mg.Schema({username:String,email:String,password:String})
mg.pluralize(null)
const u1=mg.model("user_details",myschema)
app.post("/api/signup",async(req,res)=>
{
    try
    {
        const {username,email,password}=req.body
        console.log(username)
        const hashedpassword=await bcrypt.hash(password,10)
        const newuser=new u1({username:username,email:email,password:hashedpassword})
        newuser.save();
        res.status(201).json({message:"user signed up sucessfully"})
    }
    catch(err)
    {
        res.status(500).json({error:"an error occured"})
    }
})
app.post("/api/login",async(req,res)=>
{
    try
    {
        const {username,password}=req.body
        const user=await u1.find({username})
        if(!user)
        {
            return res.status(401).json({error:"User not fount"})
        }
        const passwordmatch=await bcrypt.compare(password,user.password)
        if(!passwordmatch)
        {
            return res.status(401).json({error:"password dosnt match"})
        }
        else
        {
            return res.json({message:"login sucessful"})
        }
    }
    catch(err)
    {
        console.log(err)
        res.status(500).json({error:"an error occured"})
    }
})
const PORT=process.env.PORT ||5000;
app.listen(PORT,()=>
{
    console.log(`server running on ${PORT}`)
})

